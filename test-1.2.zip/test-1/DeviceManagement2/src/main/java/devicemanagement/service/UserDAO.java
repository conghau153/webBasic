package devicemanagement.service;

import devicemanagement.model.User;

public interface UserDAO {
    User getUser(String username);
    boolean addUser(User user);
    boolean deleteUser(String username);
}
