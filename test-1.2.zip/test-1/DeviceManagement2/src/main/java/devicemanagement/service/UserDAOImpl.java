package devicemanagement.service;

import devicemanagement.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

@Repository
public class UserDAOImpl implements UserDAO {
    @Autowired
    MongoTemplate mongoTemplate;

    String CollectionName="user";

    public User getUser(String username) {
        return mongoTemplate.findOne(Query.query(Criteria.where("username").is(username)),User.class,CollectionName);
    }

    public boolean addUser(User user) {
        User userQuery= getUser(user.getUsername());
        if (userQuery!=null)
            return false;
        else{
            mongoTemplate.insert(user,CollectionName);
            return true;
        }
    }

    public boolean deleteUser(String username) {
        User user= getUser(username);
        if (user!=null){
            mongoTemplate.remove(user,CollectionName);
            return true;
        }else
            return false;
    }
}
