package devicemanagement.model;


import java.io.Serializable;

public class ViewDevice implements Serializable {
    //default serialVersion id
    private static final long serialVersionUID = 1L;

    private String id,address, status, type, version;

    public ViewDevice() {


    }

    public ViewDevice(  String address, String status, String type, String version) {

        this.address = address;
        this.status = status;
        this.type = type;
        this.version = version;
    }

    public ViewDevice(String id, String address, String status, String type, String version) {
        this.id = id;
        this.address = address;
        this.status = status;
        this.type = type;
        this.version = version;
    }

    public ViewDevice(Device device) {
        this.id = device.getId();
        this.address = device.getAddress();
        this.status = device.getStatus();
        this.type = device.getType();
        this.version = device.getVersion();
    }

    public Device convertToDevice(){
        Device device = new Device();
        if (this.id!=null) device.setId(this.id);
        if (this.address!=null) device.setAddress(this.address);
        if (this.status!=null) device.setStatus(this.status);
        if (this.type!=null) device.setType(this.type);
        if (this.version!=null) device.setVersion(this.version);

        return device;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String toString(){
        return "["+this.getId()+" , "+ this.getAddress() + " , "
                + this.getStatus()+" , "+this.getType()+" ," + this.getVersion()+"]";
    }
}
