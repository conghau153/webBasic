package devicemanagement.schedule;

import devicemanagement.model.Device;
import devicemanagement.service.DeviceDAO;
import org.springframework.beans.factory.annotation.Autowired;

import java.awt.*;
import java.io.IOException;
import java.net.InetAddress;
import java.util.Random;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;

import static java.util.concurrent.TimeUnit.MINUTES;
import static java.util.concurrent.TimeUnit.SECONDS;

public class ScheduleExecutor {
    @Autowired
    DeviceDAO deviceDAO;


    private final ScheduledExecutorService scheduler =
            Executors.newScheduledThreadPool(1);

    final Runnable beeper = new Runnable() {
        public void run() {
            System.out.println("Scheduled ..........");
            List<Device> deviceList= deviceDAO.getListDevice();
            for (Device device: deviceList){
                try {
                    if (sendPingRequest(device.getAddress()))
                        device.setStatus("Up");
                    else
                        device.setStatus("Down");
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            for (Device device: deviceList)
                deviceDAO.updateDevice(device);

        }
    };

    final ScheduledFuture<?> beeperHandle =
            scheduler.scheduleAtFixedRate(beeper, 5, 5,MINUTES);

    public static boolean sendPingRequest(String ipAddress) throws IOException {
        InetAddress geek = InetAddress.getByName(ipAddress);
        System.out.println("Sending Ping Request to " + ipAddress);
        if (geek.isReachable(5000)){
            System.out.println("Host is reachable");
            return true;
        }
        else{
            System.out.println("Sorry ! We can't reach to this host");
            return false;
        }

    }
}
