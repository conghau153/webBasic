package devicemanagement.service;
import java.util.List;
import java.util.Random;

import devicemanagement.model.Device;
import devicemanagement.model.Event;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;


@Repository
public class DeviceDAOImpl implements DeviceDAO {
    @Autowired
    private MongoTemplate mongoTemplate;

    public static final String CollectionName = "device";


    /**
     * implement a getListDevice method return list device
     * findAll device from mongodb
     * @return a list ViewDevice
     */
    public List<Device> getListDevice() {
        List<Device> listDevice= mongoTemplate.findAll(Device.class, CollectionName);
        return listDevice;
    }

    /**
     * implement addDevice method
     * @param  device
     * @return a boolean after add
     */
    public boolean addDevice(Device device) {
        Device deviceMongo = mongoTemplate.findOne(
                Query.query(Criteria.where("_id").is(device.getId())),Device.class,CollectionName);
        Random random= new Random();
        if (deviceMongo==null){
            try {
                Thread.sleep( random.nextInt(1000));
                mongoTemplate.insert(device, CollectionName);
                return true;
            } catch (InterruptedException e) {

                e.printStackTrace();
                return false;
            }

        }
        else
            return false;
    }

    /**
     * implement updateDevice
     * @param device
     * @return a true or false after update
     */
    public boolean updateDevice(Device device) {
        Device deviceUpdate = getDeviceById(device.getId());

        if (deviceUpdate != null) {
            if (device.getName()!=null)
                deviceUpdate.setName(device.getName());
            if (device.getAddress()!=null)
                deviceUpdate.setAddress(device.getAddress());
            if (device.getType()!=null)
                deviceUpdate.setType(device.getType());
            if (device.getVersion()!=null)
                deviceUpdate.setVersion(device.getVersion());

            mongoTemplate.save(deviceUpdate, CollectionName);
            return true;
        } else {
            return false;
        }
    }

    /**
     * implements delete a device
     * @param id
     * @return check true or false after delete
     */
    public boolean deleteDevice(String id) {

        Device device= getDeviceById(id);
        if (device!=null){
            mongoTemplate.remove(device, CollectionName);
            return true;
        }else
            return false;
    }

    /**
     * implement a getDeviceById method
     * @param id
     * @return a device
     */
    public Device getDeviceById(String id) {
        //Device device=  mongoTemplate.findOne(Query.query(Criteria.where("_id").is(id)), Device.class,CollectionName);
        Device device = mongoTemplate.findById(id,Device.class,CollectionName);
        return device;
    }

    /**
     * implement a getDeviceByMacAddress
     * @param macAddress
     * @return a device by macAddress
     */
    public Device getDeviceByMacAddress(String macAddress) {
        Device device=  mongoTemplate.findOne(Query.query(Criteria.where("macAddress").is(macAddress)), Device.class,CollectionName);
        return device;
    }


    public boolean updateEvent(Event event) {
        Random random= new Random();
        Device device= getDeviceByMacAddress(event.getMacAddress());

        if (device!=null){
            try {
                device.setStatus(event.getStatus());
                Thread.sleep( random.nextInt(1000));
                mongoTemplate.save(device);

                return true;
            } catch (InterruptedException e) {
                e.printStackTrace();
                return false;
            }
        }else
            return false;
    }

    public String getMacAddress(){
        List<Device> deviceList = mongoTemplate.findAll(Device.class,"device");

        Random random= new Random();
        int i= random.nextInt(deviceList.size());

        Device device= deviceList.get(i);
        return device.getMacAddress();
    }

}