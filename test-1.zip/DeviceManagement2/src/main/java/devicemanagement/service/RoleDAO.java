package devicemanagement.service;

import devicemanagement.model.Role;

public interface RoleDAO {
    Role getRoleUser(String userId);
    boolean isExitsRoleUser(Role role);
}
