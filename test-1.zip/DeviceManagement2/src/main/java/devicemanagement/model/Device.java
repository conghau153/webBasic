package devicemanagement.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


@Document
public class Device  {
    @Id
    private String id;
    private String name,address, macAddress,status,type,version;

    public Device(){

    }

    public Device(String id, String name, String address, String macAddress, String status, String type, String version) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.macAddress = macAddress;
        this.status = status;
        this.type = type;
        this.version = version;
    }

    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getMacAddress() {
        return macAddress;
    }

    public void setMacAddress(String macAddress) {
        this.macAddress = macAddress;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    @Override
    public boolean equals(Object obj) {
        Device device = (Device) obj;
        if ((this.getId().equals(device.getId()))
            && (this.getName().equals(device.getName()))
            && (this.getAddress().equals(device.getAddress()))
            && (this.getMacAddress().equals(device.getMacAddress()))
            && (this.getStatus().equals(device.getStatus()))
            && (this.getType().equals(device.getType()))
            && (this.getVersion().equals(device.getVersion())))
            return true;
        else
            return false;

    }

}
