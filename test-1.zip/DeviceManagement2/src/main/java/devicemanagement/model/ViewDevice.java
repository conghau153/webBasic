package devicemanagement.model;


import java.io.Serializable;

public class ViewDevice implements Serializable {
    //default serialVersion id
    private static final long serialVersionUID = 1L;

    private String id, name, address, macAddress, status, type, version;

    public ViewDevice() {


    }

    public ViewDevice( String name, String address, String macAddress, String status, String type, String version) {
        this.name = name;
        this.address = address;
        this.macAddress = macAddress;
        this.status = status;
        this.type = type;
        this.version = version;
    }

    public ViewDevice(String id, String name, String address, String macAddress, String status, String type, String version) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.macAddress = macAddress;
        this.status = status;
        this.type = type;
        this.version = version;
    }

    public ViewDevice(Device device) {
        this.id = device.getId();
        this.name = device.getName();
        this.address = device.getAddress();
        this.macAddress = device.getMacAddress();
        this.status = device.getStatus();
        this.type = device.getType();
        this.version = device.getVersion();
    }

    public Device convertToDevice(){
        Device device = new Device();
        if (this.id!=null) device.setId(this.id);
        if (this.name!=null) device.setName(this.name);
        if (this.address!=null) device.setAddress(this.address);
        if (this.macAddress!=null) device.setMacAddress(this.macAddress);
        if (this.status!=null) device.setStatus(this.status);
        if (this.type!=null) device.setType(this.type);
        if (this.version!=null) device.setVersion(this.version);

        return device;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getMacAddress() {
        return macAddress;
    }

    public void setMacAddress(String macAddress) {
        this.macAddress = macAddress;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String toString(){
        return "["+this.getId()+" , "+this.getName()+" , "+ this.getAddress()+" , "+ this.getMacAddress() + " , "
                + this.getStatus()+" , "+this.getType()+" ," + this.getVersion()+"]";
    }
}
