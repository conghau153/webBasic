package devicemanagement.controller;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

import devicemanagement.service.DeviceDAO;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import devicemanagement.model.ViewDevice;
import sun.misc.BASE64Encoder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;



@Controller
public class DeviceController {

    @Autowired
    DeviceDAO deviceDAO;

    @RequestMapping(value = "/login")
    public String login(){
        return "login";
    }

    @RequestMapping(value = "/home")
    public String home(){
        return "home";
    }

    @RequestMapping(value="/logout", method = RequestMethod.GET)
    public String logout(HttpServletRequest request, HttpServletResponse response) {

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        if (auth != null){
            new SecurityContextLogoutHandler().logout(request, response, auth);
        }
        return "redirect:/login?logout";
    }

    @RequestMapping(value = "/Access_Denied")
    @ResponseBody
    public String accessDenied() {
        return "Access Denied";
    }

    @RequestMapping(value = "/devices", method = RequestMethod.GET)
    public static ModelAndView getAllDeviceByClient() throws JSONException {

        ModelAndView modelAndView= new ModelAndView("listDevice");
        List<ViewDevice> listViewDevice=new ArrayList<ViewDevice>();

        boolean checkAdmin= false;
        String username = null;
        String password = null;

        //get username
        Object auth = SecurityContextHolder.getContext().getAuthentication();

        if (auth!=null){
            Object principal = ((Authentication) auth).getPrincipal();
            if (principal instanceof UserDetails) {
                //get username, password, roles
                username= ((UserDetails)principal).getUsername();
                password= ((UserDetails) principal).getPassword();
                Object[] roles= ((UserDetails) principal).getAuthorities().toArray();
                //get role admin
                for (Object role: roles){
                    if ("ROLE_ADMIN".equals(role.toString()))
                        checkAdmin = true;
                }
            }
        }

        if (checkAdmin){

                String authString = username + ":" + password;
                String authStringEnc = new BASE64Encoder().encode(authString.getBytes());

                Client client = Client.create();

                WebResource webResource = client.resource("http://127.0.0.1:8090/DeviceManagement/api/devices");

                //send a GET with contentType and Basic Authentication
                ClientResponse response = webResource.accept("application/json;charset=UTF-8")
                        .header("Authorization", "Basic " + authStringEnc)
                        .get(ClientResponse.class);

                //check error or access
                if (response.getStatus() != 200) {
                    System.out.println("Failed : HTTP error code : "
                            + response.getStatus());
                }else{
                    //get a array JSONObject
                    JSONArray result =  response.getEntity(JSONArray.class);
                    for (int i=0; i<result.length();i++){
                        JSONObject json = (JSONObject) result.get(i);

                        //convert JSONObject to json
                        ViewDevice viewDevice = convertToViewDevice(json);
                        listViewDevice.add(viewDevice);
                    }
                }
        }

        modelAndView.addObject("user",username);
        modelAndView.addObject("list",listViewDevice);
        return modelAndView;
    }

    /**
     * convert json to viewDevice
     * @param jsonObject
     * @return a viewDevice
     */
    static ViewDevice convertToViewDevice(JSONObject jsonObject) throws JSONException {
        ViewDevice viewDevice=null;
            String id = jsonObject.getString("id");
            String name = jsonObject.getString("name");
            String address = jsonObject.getString("address");
            String macAddress = jsonObject.getString("macAddress");
            String status = jsonObject.getString("status");
            String type = jsonObject.getString("type");
            String version = jsonObject.getString("version");

            viewDevice= new ViewDevice(id,name,address,macAddress,status,type,version);

        return viewDevice;
    }

}
