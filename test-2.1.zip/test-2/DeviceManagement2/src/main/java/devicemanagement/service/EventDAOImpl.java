package devicemanagement.service;

import devicemanagement.model.Event;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import java.util.Random;

@Repository
public class EventDAOImpl implements EventDAO {

    @Autowired
    MongoTemplate mongoTemplate;

    public void addEvent(Event event) {
        Random random = new Random();
            try {
                Thread.sleep( random.nextInt(1000)+100);
                mongoTemplate.insert(event,"event");
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
    }
}
