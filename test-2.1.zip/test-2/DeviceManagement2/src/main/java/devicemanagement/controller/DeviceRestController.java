package devicemanagement.controller;


import devicemanagement.model.Device;
import devicemanagement.service.DeviceDAO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import devicemanagement.model.ViewDevice;
import java.io.IOException;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(value = "/api")
public class DeviceRestController {
    private static final Logger logger =
            LoggerFactory.getLogger(DeviceRestController.class);

    @Autowired
    DeviceDAO deviceDAO;

    @RequestMapping(value = "/devices", method = RequestMethod.GET)
    public List<ViewDevice> getAllDevice() {
        logger.debug("================================TEST========================");

        List<Device> listDevice = deviceDAO.getListDevice();

        List<ViewDevice> listAllDevice= new ArrayList<ViewDevice>();

        for (Device device: listDevice){
            ViewDevice viewDevice= new ViewDevice(device);
            listAllDevice.add(viewDevice);
        }
        return listAllDevice;
    }

    @RequestMapping(value="/devices", method = RequestMethod.POST)
    public Object addDevice(@RequestBody ViewDevice viewDevice) throws IOException {

        Map<String,Object> response;

        if (sendPingRequest(viewDevice.getAddress())==true)
            viewDevice.setStatus("Up");
        else
            viewDevice.setStatus("Down");

        if (viewDevice.getName()==null
                || viewDevice.getAddress()==null
                || viewDevice.getMacAddress()==null
                || viewDevice.getStatus()==null
                || viewDevice.getType()==null
                || viewDevice.getVersion()==null
                ){
            //return "Name or Address or MAC Address or Status or Type or Version is NULL";
            response =
                    getResponseData(viewDevice.getVersion(),
                            "create",
                            "error",
                            "failed"
                    );
            return response;
        }
        else{
            Device device= deviceDAO.getDeviceByMacAddress(viewDevice.getMacAddress());
            if (device!=null){
                //return "MAC Address is existed";
                response =
                        getResponseData(viewDevice.getVersion(),
                                "create",
                                "error",
                                "failed"
                        );
                return response;
            }
            else{
                device = viewDevice.convertToDevice();
                boolean check= deviceDAO.addDevice(device);
                if (check){
                    response =
                        getResponseData(
                                viewDevice.getVersion(),
                                "create",
                                "success",
                                "succeed"
                        );
                    return response;
                }else{
                    //return "Error create";
                    response =
                            getResponseData(viewDevice.getVersion(),
                                    "create",
                                    "error",
                                    "failed"
                            );
                    return response;
                }
            }
        }
    }

//    @RequestMapping(value = "/devices/{id}", method = RequestMethod.GET)
//    public  Object getDeviceById(@PathVariable String id) {
//        Device device = deviceDAO.getDeviceById(id);
//        if (device != null) {
//            ViewDevice viewDevice = new ViewDevice(device);
//            return viewDevice;
//        }
//        else
//            return "Not Found Device";
//    }

//    @RequestMapping(value = "/devices/macAddress/{macAddress}", method = RequestMethod.GET)
//    public Object getDeviceByMacAddress(@PathVariable String macAddress) {
//        Device device = deviceDAO.getDeviceByMacAddress(macAddress);
//
//        if (device != null) {
//            ViewDevice viewDevice = new ViewDevice(device);
//            return viewDevice;
//        }
//        else
//            return "Not Found Device";
//    }

//    @RequestMapping(value = "/devices/{id}", method = RequestMethod.DELETE)
//    public Device deleteDeviceById(@PathVariable String id)  {
//        Device device = deviceDAO.getDeviceById(id);
//        boolean check= deviceDAO.deleteDevice(id);
//        if (check){
//                //return "Deleted";
//            return device;
//        }else{
//            return null;
//            //return "Error delete";
//        }
//
//    }

    @RequestMapping(value = "/devices/multiDevice/{idList}",method = RequestMethod.DELETE)
    public Object deleteMultiDevice(@PathVariable List<String> idList){

        Map<String,Object> response;

        boolean check=true;
        for (String id:idList){
            if (deviceDAO.getDeviceById(id)==null)
                check=false;
        }
        if (check==false){
            //return " Error delete Multi device";
            response= getResponseData("","delete","error","failed");
            return response;
        }else
        {
            for (String id: idList)
                deviceDAO.deleteDevice(id);

            //return "Deleted multi device";
            response= getResponseData("","delete","success","succeed");
            return response;
        }
    }

    @RequestMapping(value = "/devices/{id}", method = RequestMethod.PUT)
    public Object updateDevice(@PathVariable String id, @RequestBody ViewDevice viewDevice) {
        Map<String,Object> response;

        viewDevice.setId(id);
        Device deviceUpdate= viewDevice.convertToDevice();
        boolean ok= deviceDAO.updateDevice(deviceUpdate);
        if (ok){
            //return "Updated!";
            response = getResponseData(viewDevice.getVersion(),"update","success","succeed");
            return response;
        }
        else{
            //return "Error update";
            response = getResponseData(viewDevice.getVersion(),"update","error","failed");
            return response;
        }

    }

    public static boolean sendPingRequest(String ipAddress) throws IOException {
        InetAddress geek = InetAddress.getByName(ipAddress);
        System.out.println("Sending Ping Request to " + ipAddress);
        if (geek.isReachable(5000)){
            System.out.println("Host is reachable");
            return true;
        }
        else{
            System.out.println("Sorry ! We can't reach to this host");
            return false;
        }
    }

    public Map<String,Object> getResponseData(String version, String operator,String status,String statusResponse) {
        Map<String,Object> message= new HashMap<String, Object>();
        message.put("code",operator+"."+status);
        message.put("params",new ArrayList());

        Map<String,Object> data= new HashMap<String, Object>();
        data.put("wmaInstancePort",8090);

        Map<String,Object> response= new HashMap<String, Object>();
        response.put("status",statusResponse.toUpperCase());
        response.put("message",message);
        response.put("data",data);

        Map<String,Object> responseData= new HashMap<String, Object>();
        responseData.put("status","SUCCESS");
        responseData.put("statusCode",200);
        responseData.put("type","application/json;charset=UTF-8");
        responseData.put("response",response);
        responseData.put("serverVersion",version);
        return  responseData;
    }
}
