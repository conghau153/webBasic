package devicemanagement.custom;


import devicemanagement.model.Role;
import devicemanagement.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import devicemanagement.service.RoleDAO;
import devicemanagement.service.UserDAO;


import java.util.ArrayList;
import java.util.List;

@Service("customUserDetailsService")
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired
    UserDAO userDAO;

    @Autowired
    RoleDAO roleDAO;

    public UserDetails loadUserByUsername(String username)
            throws UsernameNotFoundException {

        User user = userDAO.getUser(username) ;
        System.out.println(user);
        System.out.println("UserDevice : "+user);
        if(user==null){
            System.out.println("UserDevice not found");
            //throw new UsernameNotFoundException("Username not found");
            return  null;
        }

        return new org.springframework.security.core.userdetails.User(user.getUsername(), user.getPassword(),
                true, true, true, true,
                getGrantedAuthorities(user));
    }


    private List<GrantedAuthority> getGrantedAuthorities(User user){
        List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();

        List<Role> listRoleUser = roleDAO.getRoleUser(user.getId());
        for (Role role : listRoleUser){
            authorities.add(new SimpleGrantedAuthority(role.getRole()));
        }

        System.out.print("authorities :"+authorities);
        return authorities;
    }
}
