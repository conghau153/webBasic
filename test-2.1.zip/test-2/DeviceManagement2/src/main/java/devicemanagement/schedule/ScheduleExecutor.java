package devicemanagement.schedule;

import devicemanagement.model.Device;
import devicemanagement.model.Event;
import devicemanagement.observer.Subject;
import devicemanagement.service.DeviceDAO;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.IOException;
import java.net.InetAddress;
import java.util.List;
import java.util.Random;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;

import static java.util.concurrent.TimeUnit.MINUTES;
import static java.util.concurrent.TimeUnit.SECONDS;

public class ScheduleExecutor {
    @Autowired
    DeviceDAO deviceDAO;

    @Autowired
    Subject subject;

    private final ScheduledExecutorService scheduler =
            Executors.newScheduledThreadPool(1);

    final Runnable beeper = new Runnable() {
        public void run() {
//            Event event= new Event();
//            event.setMacAddress(deviceDAO.getMacAddress());
//            event.setStatus(getRandomStatus());
//            subject.setEvent(event);
            System.out.println("Scheduled ..........");
            List<Device> deviceList= deviceDAO.getListDevice();
            for (Device device: deviceList){
                try {
                    if (sendPingRequest(device.getAddress()))
                        device.setStatus("Up");
                    else
                        device.setStatus("Down");
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            for (Device device: deviceList)
                deviceDAO.updateDevice(device);
        }
    };

    final ScheduledFuture<?> beeperHandle =
            scheduler.scheduleAtFixedRate(beeper, 5, 5,MINUTES);


//    String getRandomStatus(){
//        Random random = new Random();
//        int idx= random.nextInt(3);
//
//        if (idx==0)
//            return  "Warning";
//        else
//        if (idx==1)
//            return  "Up";
//        else
//            return  "Down";
//    }

    public static boolean sendPingRequest(String ipAddress) throws IOException {
        InetAddress geek = InetAddress.getByName(ipAddress);
        System.out.println("Sending Ping Request to " + ipAddress);
        if (geek.isReachable(5000)){
            System.out.println("Host is reachable");
            return true;
        }
        else{
            System.out.println("Sorry ! We can't reach to this host");
            return false;
        }
    }
}
