package devicemanagement.controller;

import devicemanagement.model.User;
import devicemanagement.model.ViewDevice;
import org.codehaus.jettison.json.JSONException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;


public class DeviceControllerTest {

    @InjectMocks
    private DeviceController deviceController;

    User user= new User();
    String roleUser= "ROLE_ADMIN";

    @Before
    public void init(){
        MockitoAnnotations.initMocks(this);

        user.setId("12541df1s4f112");
        user.setUsername("admin");
        user.setPassword("admin");
    }

    @Test
    public void TestLogin(){
        assertEquals("login", deviceController.login());
    }

    @Test
    public void TestAccessDenied(){
        assertEquals("Access Denied",deviceController.accessDenied());
    }

    @Test
    public void TestLogout() {
        HttpServletRequest request = mock(HttpServletRequest.class);
        HttpServletResponse response = mock(HttpServletResponse.class);
        setupUser(user, roleUser);

        assertEquals("redirect:/login?logout",deviceController.logout(request,response));
    }

    @Test
    public void TestGetAllDevicesClient() throws JSONException {
        ModelAndView modelAndView= new ModelAndView("listDevice");
        List<ViewDevice> listViewDevice=new ArrayList<ViewDevice>();
        setupUser(user, roleUser);

        modelAndView.addObject("user",null);
        modelAndView.addObject("list",listViewDevice);
        deviceController.getAllDeviceByClient();
    }

    public void setupUser(User user,String roleUser){
        List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
        authorities.add(new SimpleGrantedAuthority(roleUser));

        org.springframework.security.core.userdetails.User userDetails =
                new org.springframework.security.core.userdetails.User(
                        user.getUsername(),
                        user.getPassword(),
                        true, true, true, true,
                        authorities);

        Authentication auth = new UsernamePasswordAuthenticationToken(userDetails,null);
        SecurityContextHolder.getContext().setAuthentication(auth);
    }
}
