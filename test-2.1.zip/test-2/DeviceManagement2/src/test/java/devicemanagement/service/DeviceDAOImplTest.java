package devicemanagement.service;

import devicemanagement.model.Device;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static junit.framework.TestCase.assertEquals;
import static org.mockito.Mockito.when;


@RunWith(MockitoJUnitRunner.class)
public class DeviceDAOImplTest {
    @Mock
    MongoTemplate mongoTemplate;

    @InjectMocks
    DeviceDAOImpl deviceDAO;

    static Device device, device2, deviceQuery;

    @Before
    public void init(){
        device= new Device();
        device.setId("5be15357f9d8487d938669a7");
        device.setName("vxTarget");
        device.setAddress("10.1.2.125");
        device.setMacAddress("eB:e7:32:de:f0:9B");
        device.setStatus("Up");
        device.setType("0S6450-U245");
        device.setVersion("6.7.2.107");

        device2= new Device();
        device2.setId("5be15364f9d8487d938669a8");
        device2.setName("ABC");
        device2.setAddress("10.1.3.5");
        device2.setMacAddress("eB:f2:32:gd:f0:9B");
        device2.setStatus("Up");
        device2.setType("0S6450-U245");
        device2.setVersion("6.7.2.5");

        deviceQuery= new Device();
        deviceQuery.setId("5be15364f9d8487d938669a10");
        deviceQuery.setName("DCD-2");
        deviceQuery.setAddress("10.1.3.95");
        deviceQuery.setMacAddress("eB:f2:32:f3:a3:9h");
        deviceQuery.setStatus("Up");
        deviceQuery.setType("0S5686200");
        deviceQuery.setVersion("8.1.2.1");

    }

    @Test
    public void getListDeviceTest() {
        List<Device> list_device = new ArrayList<Device>(Arrays.asList(new Device[]{device, device2 }));
        when(
                mongoTemplate.findAll(Device.class,"device")
        ).thenReturn(list_device);

        assertEquals(list_device,deviceDAO.getListDevice());
    }

    @Test
    public void addDeviceTest() {
        when(mongoTemplate.findOne(
                Query.query(Criteria.where("_id").is(device.getId())),
                Device.class,
                "device")
        ).thenReturn(deviceQuery);

        when(mongoTemplate.findOne(
                Query.query(Criteria.where("_id").is(device2.getId())),
                Device.class,
                "device")
        ).thenReturn(null);

        assertEquals(false,deviceDAO.addDevice(device));
        assertEquals(true,deviceDAO.addDevice(device2));
    }

    @Test
    public void updateDevice() {
        when(deviceDAO.getDeviceById(device.getId())).thenReturn(device);
        when(deviceDAO.getDeviceById(device2.getId())).thenReturn(null);

        assertEquals(true,deviceDAO.updateDevice(device));
        assertEquals(false,deviceDAO.updateDevice(device2));
    }

    @Test
    public void deleteDevice() {
        when(deviceDAO.getDeviceById("5be15357f9d8487d938669a7")).thenReturn(device);

        when(deviceDAO.getDeviceById("5be15357f9d8487d938669a12")).thenReturn(null);

        assertEquals(true,deviceDAO.deleteDevice("5be15357f9d8487d938669a7"));
        assertEquals(false,deviceDAO.deleteDevice("5be15357f9d8487d938669a12"));

    }

    @Test
    public void getDeviceById() {
        when(
                mongoTemplate.findById("5be15357f9d8487d938669a7",Device.class,"device")
        ).thenReturn(device);

        assertEquals(device,deviceDAO.getDeviceById("5be15357f9d8487d938669a7"));
    }

    @Test
    public void getDeviceByMacAddress() {
        when(
                mongoTemplate.findOne(
                        Query.query(Criteria.where("macAddress").is("eB:e7:32:de:f0:9B")),
                        Device.class,
                        "device")
        ).thenReturn(device);

        assertEquals(device,deviceDAO.getDeviceByMacAddress("eB:e7:32:de:f0:9B"));
    }

}