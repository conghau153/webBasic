package devicemanagement.controller;

import devicemanagement.model.Device;
import devicemanagement.model.User;
import devicemanagement.service.DeviceDAO;
import devicemanagement.service.UserDAO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import devicemanagement.model.ViewDevice;

import java.io.IOException;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping(value = "/api")
public class DeviceRestController {
    private static final Logger logger =
            LoggerFactory.getLogger(DeviceRestController.class);

    @Autowired
    DeviceDAO deviceDAO;

    @Autowired
    UserDAO userDAO;


    @RequestMapping(value = "/devices", method = RequestMethod.GET)
    public List<ViewDevice> getAllDevice()  {
        logger.debug("================================TEST========================");

        List<Device> listDevice = deviceDAO.getListDevice();

        List<ViewDevice> listAllDevice= new ArrayList<ViewDevice>();

        for (Device device: listDevice){
            ViewDevice viewDevice= new ViewDevice(device);

            listAllDevice.add(viewDevice);
        }
        return listAllDevice;
    }


    @RequestMapping(value="/devices", method = RequestMethod.POST)
    public ViewDevice addDevice(@RequestBody ViewDevice viewDevice) throws IOException {
        if (viewDevice.getAddress()!=null && viewDevice.getType()!=null && viewDevice.getVersion()!=null){

            if (sendPingRequest(viewDevice.getAddress())==true)
                viewDevice.setStatus("Up");
            else
                viewDevice.setStatus("Down");

            Device device= deviceDAO.getDeviceByAddress(viewDevice.getAddress());
            Device device1= viewDevice.convertToDevice();


            if (device!=null){
                deviceDAO.updateDevice(device1);
            }
            else{
                deviceDAO.addDevice(device1);
            }
            return viewDevice;
        }
        else
            return null;
    }


    @RequestMapping(value = "/devices/{address}", method = RequestMethod.DELETE)
    public Device deleteDeviceById(@PathVariable  String address)  {
        Device device= deviceDAO.getDeviceByAddress(address);
        if (device!=null){
            deviceDAO.deleteDevice(address);
            return device;
        }else{
            return null;
        }
    }

    @RequestMapping(value = "/user/{username}/{password}", method = RequestMethod.GET)
    public User getUser(@PathVariable String username,@PathVariable String password){
        User user= userDAO.getUser(username);
        if (user!=null){
            if (username.equalsIgnoreCase(user.getUsername()) && password.equalsIgnoreCase(user.getPassword()))
                return user;
            else
                return null;
        }else
            return null;

    }

    @RequestMapping(value = "/user", method = RequestMethod.POST)
    public User addUser(@RequestBody User user){
        if (user.getUsername()!=null && user.getPassword()!=null){
            boolean check= userDAO.addUser(user);
            if (check)
                return user;
            else
                return null;
        }else
            return null;
    }

    public static boolean sendPingRequest(String ipAddress) throws IOException {
        InetAddress geek = InetAddress.getByName(ipAddress);
        System.out.println("Sending Ping Request to " + ipAddress);
        if (geek.isReachable(5000)){
            System.out.println("Host is reachable");
            return true;
        }
        else{
            System.out.println("Sorry ! We can't reach to this host");
            return false;
        }
    }
}