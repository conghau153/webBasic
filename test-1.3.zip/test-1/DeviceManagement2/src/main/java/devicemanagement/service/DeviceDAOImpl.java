package devicemanagement.service;
import java.util.List;
import java.util.Random;

import devicemanagement.model.Device;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;


@Repository
public class DeviceDAOImpl implements DeviceDAO {
    @Autowired
    private MongoTemplate mongoTemplate;

    public static final String CollectionName = "device";



    public List<Device> getListDevice() {
        List<Device> listDevice= mongoTemplate.findAll(Device.class, CollectionName);
        return listDevice;
    }


    public boolean addDevice(Device device) {
        Device deviceMongo = mongoTemplate.findOne(
                Query.query(Criteria.where("_id").is(device.getId())),Device.class,CollectionName);
        Random random= new Random();
        if (deviceMongo==null){
            try {
                Thread.sleep( random.nextInt(1000));
                mongoTemplate.insert(device, CollectionName);
                return true;
            } catch (InterruptedException e) {

                e.printStackTrace();
                return false;
            }

        }
        else
            return false;
    }


    public boolean updateDevice(Device device) {
        Device deviceUpdate = getDeviceByAddress(device.getAddress());

        if (deviceUpdate != null) {
            if (device.getType()!=null)
                deviceUpdate.setType(device.getType());
            if (device.getVersion()!=null)
                deviceUpdate.setVersion(device.getVersion());

            mongoTemplate.save(deviceUpdate, CollectionName);
            return true;
        } else {
            return false;
        }
    }

    public boolean deleteDevice(String address) {

        Device device= getDeviceByAddress(address);
        if (device!=null){
            mongoTemplate.remove(device, CollectionName);
            return true;
        }else
            return false;
    }


    public Device getDeviceById(String id) {
        //Device device=  mongoTemplate.findOne(Query.query(Criteria.where("_id").is(id)), Device.class,CollectionName);
        Device device = mongoTemplate.findById(id,Device.class,CollectionName);
        return device;
    }


    public Device getDeviceByAddress(String macAddress) {
        Device device=  mongoTemplate.findOne(Query.query(Criteria.where("address").is(macAddress)), Device.class,CollectionName);
        return device;
    }




}