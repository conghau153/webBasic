package devicemanagement.service;
import devicemanagement.model.Device;

import java.util.List;

public interface DeviceDAO {

    List<Device> getListDevice();

    boolean addDevice(Device device);

    boolean updateDevice(Device device);

    boolean deleteDevice(String address);

    Device getDeviceById(String id);

    Device getDeviceByAddress(String address);


}