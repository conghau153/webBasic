var app = angular.module('myApp', []);
app.controller('myCtrl', function($scope, $http) {

    $scope.getDevices = function() {
        $http.get("http://127.0.0.1:8090/DeviceManagement/api/devices").then(
            function(response) {
                $scope.records = response.data;
                console.log(response.data);
            });
    };

    $scope.SendData = function () {
        //use $.param jQuery function to serialize data from JSON
        var data ={
            "address":$scope.address,
            "type":$scope.type,
            "version":$scope.version
        }
        console.log("{"+data.address+ " ," + data.type + " ," + data.version + "}");
        var config = {
            headers : {
                "Content-Type": "application/json;charset=utf-8;"
            }
        }
        $http.post('http://127.0.0.1:8090/DeviceManagement/api/devices', data, config)
            .then(function(){
                $scope.getDevices();
                console.log("created")
            })

    };

    $scope.DeleteData=function(){
        var address= $scope.address
        $http.delete('http://127.0.0.1:8090/DeviceManagement/api/devices/'+address+".")
            .then(function(response){
                $scope.getDevices();
                console.log("deleted: "+response)
            })
    }

    ////////////////
    $scope.getDevices();

});

var user= angular.module('myAppUser',[]);
user.controller('myUser',function ($scope,$http) {
    $scope.validate_login = function() {
        var username= $scope.username;
        var password= $scope.password;
        //console.log(username+" , "+ password);
        $http.get("http://127.0.0.1:8090/DeviceManagement/api/user/"+username+"/"+password)
            .then(
                function(response) {
                    //$scope.records = response.data;
                    if (response.data!=""){
                        console.log("success Login")
                        location.replace("index.html")
                    }else{
                        $scope.errorLogin="Error username or password !"
                        console.log($scope.errorLogin)

                    }
                })

    };

    $scope.Register= function () {
        var username= $scope.email;
        var password= $scope.password;

        if (username!="" && password!="" && $scope.validate()==true){
            var data={
                "username":username,
                "password":password
            }
            var config = {
                headers : {
                    "Content-Type": "application/json;charset=utf-8;"
                }
            }
            $http.post('http://127.0.0.1:8090/DeviceManagement/api/user', data, config)
                .then(function(response){
                    if (response.data!=""){
                        $scope.successRegister="Successful Register"
                        $scope.errorRegister=""
                        console.log("created :["+response.data.username +", "+ response.data.password+"]")
                    }
                    else{
                        $scope.errorRegister="Error Email or Password !"
                        $scope.successRegister=""
                        console.log("error !")
                    }

                })
        }else{
            $scope.errorRegister="Error Email or Password !"
            $scope.successRegister=""
        }

    };
    $scope.validate= function() {
        var email = $scope.email;
        var pos1 = email.indexOf("@");
        var pos2 = email.lastIndexOf(".");
        if (pos1 < 1 || pos2 < pos1 + 2 || pos2 + 2 >= email.length) {
            //alert("Not a valid e-mail address");
            return false;
        }else
            return true;
    };

});


