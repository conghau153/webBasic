package devicemanagement.service;

import devicemanagement.model.Role;
import devicemanagement.model.User;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

import java.util.Arrays;
import java.util.List;

import static devicemanagement.service.RoleDAOImpl.CollectionRoleUser;
import static junit.framework.TestCase.assertEquals;
import static org.mockito.Mockito.when;


@RunWith(MockitoJUnitRunner.class)
public class RoleDAOImplTest {
    @Mock
    MongoTemplate mongoTemplate;

    @InjectMocks
    RoleDAOImpl roleDAO;

    Role role = new Role();

    @Before
    public void init(){
        role.setId("12452@dfe1as212");
        role.setRole("ROLE_ADMIN");
        role.setUserId("45652fsjd125123");
    }

    @Test
    public void getRoleUser() {
       List<Role> roles = Arrays.asList(new Role[]{role});
       when(mongoTemplate.find(
               Query.query(Criteria.where("userId").is("45652fsjd125123")), Role.class,CollectionRoleUser)
       ).thenReturn(roles);

       assertEquals(roles,roleDAO.getRoleUser("45652fsjd125123"));


    }
}