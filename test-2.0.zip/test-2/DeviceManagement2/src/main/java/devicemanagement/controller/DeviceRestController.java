package devicemanagement.controller;

import devicemanagement.model.Device;
import devicemanagement.service.DeviceDAO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import devicemanagement.model.ViewDevice;

import java.io.IOException;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping(value = "/api")
public class DeviceRestController {
    private static final Logger logger =
            LoggerFactory.getLogger(DeviceRestController.class);

    @Autowired
    DeviceDAO deviceDAO;

    /**
     * get all device
     * RequestMethod GET
     * @return list device
     */
    @RequestMapping(value = "/devices", method = RequestMethod.GET)
    public List<ViewDevice> getAllDevice() {
        logger.debug("================================TEST========================");

        List<Device> listDevice = deviceDAO.getListDevice();

        List<ViewDevice> listAllDevice= new ArrayList<ViewDevice>();

        for (Device device: listDevice){
            ViewDevice viewDevice= new ViewDevice(device);
            listAllDevice.add(viewDevice);
        }
        return listAllDevice;
    }

    @RequestMapping(value="/devices", method = RequestMethod.POST)
    public ViewDevice addDevice(@RequestBody ViewDevice viewDevice) throws IOException {

        Device device=null;

        if (sendPingRequest(viewDevice.getAddress())==true)
            viewDevice.setStatus("Up");
        else
            viewDevice.setStatus("Down");

        if (viewDevice.getName()==null
                || viewDevice.getAddress()==null
                || viewDevice.getMacAddress()==null
                || viewDevice.getStatus()==null
                || viewDevice.getType()==null
                || viewDevice.getVersion()==null
                ){
            //return "Name or Address or MAC Address or Status or Type or Version is NULL";
            return null;
        }
        else{
            device= deviceDAO.getDeviceByMacAddress(viewDevice.getMacAddress());
            if (device!=null){
                //return "MAC Address is existed";
                return null;
            }
            else{

                device = viewDevice.convertToDevice();
                boolean check= deviceDAO.addDevice(device);
                if (check){
                    //return "Created";
                    return viewDevice;
                }else{
                    //return "Error create";
                    return null;
                }
            }
        }
    }

    /**
     * get a device by id
     * @param id
     * @return a device or status: not found device
     */
    @RequestMapping(value = "/devices/{id}", method = RequestMethod.GET)
    public  Object getDeviceById(@PathVariable String id) {
        Device device = deviceDAO.getDeviceById(id);
        if (device != null) {
            ViewDevice viewDevice = new ViewDevice(device);
            return viewDevice;
        }
        else
            return "Not Found Device";
    }

    /**
     * get a device by macAddress
     * RequestMethod GET
     * @param macAddress
     * @return a device or status: not found device
     */
    @RequestMapping(value = "/devices/macAddress/{macAddress}", method = RequestMethod.GET)
    public Object getDeviceByMacAddress(@PathVariable String macAddress) {
        Device device = deviceDAO.getDeviceByMacAddress(macAddress);

        if (device != null) {
            ViewDevice viewDevice = new ViewDevice(device);
            return viewDevice;
        }
        else
            return "Not Found Device";
    }


    /**
     * Delete a device by id
     * RequestMethod DELETE
     * send a device to queue jmsMessage-1
     * receive a status from queue jmsMessage-2
     * @param id
     * @return status after delete
     */
    @RequestMapping(value = "/devices/{id}", method = RequestMethod.DELETE)
    public Device deleteDeviceById(@PathVariable String id)  {
        Device device = deviceDAO.getDeviceById(id);
        boolean check= deviceDAO.deleteDevice(id);
        if (check){
                //return "Deleted";
            return device;
        }else{
            return null;
            //return "Error delete";
        }

    }
    @RequestMapping(value = "/devices/multiDevice/{idList}",method = RequestMethod.DELETE)
    public List<String> deleteMultiDevice(@PathVariable List<String> idList){

        boolean check=true;
        for (String id:idList){
            if (deviceDAO.getDeviceById(id)==null)
                check=false;
        }
        if (check==false){
            //return " Error delete Multi device";
            return null;
        }else
        {
            for (String id: idList)
                deviceDAO.deleteDevice(id);

            //return "Deleted multi device";
            return idList;
        }
    }

    /**
     * update device
     * find device by id
     * check update device
     * @param id
     * @param viewDevice
     * @return status update
     */
    @RequestMapping(value = "/devices/{id}", method = RequestMethod.PUT)
    public ViewDevice updateDevice(@PathVariable String id, @RequestBody ViewDevice viewDevice) {

            if (viewDevice.getId()!=null || viewDevice.getMacAddress()!=null || viewDevice.getStatus()!=null){
                //return "User can only modify the following attributes: name, address, type, version";
                return null;
            }else
                if (viewDevice.getName()==null
                        && viewDevice.getAddress()==null
                        && viewDevice.getType()==null
                        && viewDevice.getVersion()==null)
               // return "name and address and type and version are NULL";
                    return null;
            else
                {

                    viewDevice.setId(id);
                    Device deviceUpdate= viewDevice.convertToDevice();
                    boolean ok= deviceDAO.updateDevice(deviceUpdate);
                    if (ok)
                        //return "Updated!";
                        return viewDevice;
                    else
                        //return "Error update";
                        return null;
                }

    }
    public static boolean sendPingRequest(String ipAddress) throws IOException {
        InetAddress geek = InetAddress.getByName(ipAddress);
        System.out.println("Sending Ping Request to " + ipAddress);
        if (geek.isReachable(5000)){
            System.out.println("Host is reachable");
            return true;
        }
        else{
            System.out.println("Sorry ! We can't reach to this host");
            return false;
        }
    }
}