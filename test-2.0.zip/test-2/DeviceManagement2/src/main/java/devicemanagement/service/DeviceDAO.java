package devicemanagement.service;
import devicemanagement.model.Device;
import devicemanagement.model.Event;

import java.util.List;

public interface DeviceDAO {

    List<Device> getListDevice();

    boolean addDevice(Device device);

    boolean updateDevice(Device device);

    boolean deleteDevice(String id);

    Device getDeviceById(String id);

    Device getDeviceByMacAddress(String macAddress);

    boolean updateEvent(Event event);
    String getMacAddress();

}