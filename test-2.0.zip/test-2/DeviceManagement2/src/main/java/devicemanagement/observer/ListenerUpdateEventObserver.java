package devicemanagement.observer;

import devicemanagement.service.DeviceDAO;
import org.springframework.beans.factory.annotation.Autowired;

public class ListenerUpdateEventObserver extends  Observer{
    @Autowired
    DeviceDAO deviceDAO;

    public ListenerUpdateEventObserver(Subject subject) {
        this.subject = subject;
        this.subject.attach(this);
    }

    public void update() {
        //save to mongodb
        deviceDAO.updateEvent(subject.getEvent());
        System.out.println("update Mongodb collection = device : " + subject.getEvent().toString());
    }
}
