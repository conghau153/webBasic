function myRegister() {
    var table = document.getElementById("myTable");
    var ip= document.getElementById("ip").value;
    var type=document.getElementById("select").value;

    if (ip!=""){
        var row= table.insertRow();
        var ipCell= row.insertCell(0);
        var typeCell= row.insertCell(1);
        var statusCell= row.insertCell(2);
        var versionCell= row.insertCell(3);
        ipCell.innerHTML= ip;
        typeCell.innerHTML= type;
    }

}


