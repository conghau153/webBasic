

function validate_login() {
    var email = document.getElementById("email").value;
    var password = document.getElementById("password").value;


    var passStory= localStorage.getItem(email);

    if (email!=null && password!=null && passStory==password ) {
       // alert("Login successfully");
        window.location = "login-success.html"; // Redirecting to other page.
        return false;
    } else {
        document.getElementById("error").innerHTML="Error email or password";
        //alert("Error username or password");
    }
}
function validate_register() {
    var email= document.getElementById("email").value;
    var password = document.getElementById("password").value;



    if ( window.localStorage.getItem(email)!=null || checkEmail(email)==false){
        document.getElementById("errorRegister").innerHTML="Register error email or password";
        document.getElementById("successRegister").innerHTML="";
    }else{
        window.localStorage.setItem(email, password);



        document.getElementById("successRegister").innerHTML="Register successful";
        document.getElementById("errorRegister").innerHTML="";
    }

}
function checkEmail(email){
    var pos1 = email.indexOf("@");
    var pos2 = email.lastIndexOf(".");
    if (pos1 < 1 || pos2 < pos1 + 2 || pos2 + 2 >= email.length) {
        //alert("Not a valid e-mail address");
        return false;
    }else
        return true;
}