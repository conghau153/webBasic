
var authen= btoa("admin:admin");
var app = angular.module('myApp', ["ngRoute"])

var id="";
var check=false;
var listDevice= new Array();
var checkMacAddress = /^(([A-Fa-f0-9]{2}[:]){5}[A-Fa-f0-9]{2}[,]?)+$/;
var checkIpAddress= /^([0-9]{1,3})[.]([0-9]{1,3})[.]([0-9]{1,3})[.]([0-9]{1,3})$/; 

app.config(function($httpProvider) {
    $httpProvider.defaults.headers.common['Authorization'] = 'Basic ' + authen;
})
app.config(function($routeProvider) {
    $routeProvider
        .when("/", {
            templateUrl : "page/home.html"
        })
        .when("/create", {
            templateUrl : "page/create.html"
        })
        .when("/edit", {
            templateUrl : "page/edit.html"
        });
});
app.controller('myCtrl', function($scope, $http) {
    $scope.getDevices = function () {
        $http.get("http://127.0.0.1:8090/DeviceManagement/api/devices").then(
            function (response) {
                $scope.records = response.data;
                console.log(response.data);
            });

    };
    $scope.getDevices();

    $scope.SendData = function () {
        var data ={
            "name":$scope.device.name,
            "address":$scope.device.address,
            "macAddress":$scope.device.macAddress,
            "type":$scope.device.type,
            "version":$scope.device.version
        }

        console.log("{"+data.name+", "+ data.address+ ", "+data.macAddress+", " + data.type + ", " + data.version + "}");
        if (checkSendData(data)==true){
            var config = {
                headers : {
                    "Content-Type": "application/json;charset=utf-8;"
                }
            }
            var checkCreate= confirm("You want create a device");
            if (checkCreate==true){
               // $scope.device={};
                console.log("You pressed OK");
                $http.post('http://127.0.0.1:8090/DeviceManagement/api/devices', data, config)
                    .then(function(response){
                        if (response.data.response.status=="SUCCEED"){
                            alert("Successful create a device");
                            window.location = "index.html";
                            console.log("created ")
                        }
                        else{
                            alert("Error create a device !")
                            console.log("error create!")
                        }
                    })
            }else{
                console.log("You pressed CANCEL")
                window.location = "index.html";
            }
        }else{
            confirm("You must enter value device!!");
        }
    };

    $scope.checkDevice = function(device) {
        console.log("device: ["+device.id+","+ device.name+","+device.address+","+device.macAddress+","+device.status+","+device.type+","+device.version+"]");
        check=device.selected;
        if (check==true)
            listDevice.push(device);
        else
            removeIndexArray(listDevice,device);
        if(listDevice.length>0){
            id=listDevice[listDevice.length-1].id;
            $scope.nameEdit= listDevice[listDevice.length-1].name;
            $scope.addressEdit= listDevice[listDevice.length-1].address;
            $scope.typeEdit= listDevice[listDevice.length-1].type;
            $scope.versionEdit= listDevice[listDevice.length-1].version;
        }
        if (listDevice.length!=1)
            $scope.disableEdit=false;
        else
            $scope.disabledEdit=true;
    };

    $scope.DeleteDevice= function () {
        if (listDevice.length>0){
            $scope.disabledDelete=false;
            $scope.statusDelete="#";

            $scope.nameEdit="";
            $scope.addressEdit="";
            $scope.typeEdit="";
            $scope.versionEdit="";

            var listId=[];
            for(var i=0;i<listDevice.length;i++){
                listId.push(listDevice[i].id);
            }

            var checkConfirm= confirm("You want delete a device?");
            if (checkConfirm==true){
                console.log("You pressed OK");
                $http.delete("http://127.0.0.1:8090/DeviceManagement/api/devices/multiDevice/"+listId).then(
                    function (response) {
                        if (response.data.response.status=="SUCCEED"){
                            alert("Successful delete device")
                            $scope.getDevices();
                            listDevice=new Array();
                        }
                        else{
                            alert("Error delete device")
                            $scope.getDevices();
                        }

                    });
                myReload();
            }else{
                console.log("You pressed Cancel");
                myReload();
            }

        }else{
            //confirm("you must select a device");
            $scope.disabledDelete=true;
        }


    }

    $scope.EditDevice= function () {
            var data = {
                "name": $scope.nameEdit,
                "address": $scope.addressEdit,
                "type": $scope.typeEdit,
                "version": $scope.versionEdit
            };
            listDevice = new Array();
            var config = {
                headers: {
                    "Content-Type": "application/json;charset=utf-8;"
                }
            };
            if (data.name == null || data.address == null || data.type == null || data.version == null) {
                if (data.name==null)
                    alert("You must enter value Name");
                else
                    if (data.address==null)
                        alert("You must enter value IP Address");
                    else
                        if (data.type==null)
                            alert("You must enter value Type");
                        else
                            if (data.version==null)
                                alert("You must enter value Version");
            } else {
                var checkEditDevice = confirm("You want edit device?");
                if (checkEditDevice == true) {


                    console.log("You pressed OK");
                    $http.put('http://127.0.0.1:8090/DeviceManagement/api/devices/' + id, data, config)
                        .then(function (response) {
                            if (response.data.response.status == "SUCCEED") {
                                alert("successful update a device");

                                console.log("updated ")
                            }
                            else {
                                alert("Error update device");
                                console.log("error update!");

                            }
                        })
                    $scope.nameEdit=null;
                    $scope.addressEdit=null;
                    $scope.typeEdit=null;
                    $scope.versionEdit=null;

                    window.location = "index.html";
                } else {

                    console.log("You pressed CANCEL");
                    window.location = "index.html";
                }
            }


    }

    $scope.checkEdit=function () {
        if (listDevice.length != 1) {
            $scope.disabledEdit= true;
        }
        else{
            $scope.disabledEdit=false;
            $scope.statusEdit="#!edit";
        }
    }

    $scope.Cancel= function () {
        var checkCancel= confirm("you want cancel ?");
        if (checkCancel==true)
            window.location="index.html";
    }

});

function checkSendData(device) {
    if (device.name==null || device.address==null || device.macAddress==null  || device.type==null || device.version==null)
        return false;
    else
        return true;
}
function removeIndexArray(devices, device) {
    for (var i=0;i<devices.length;i++){
        if (checkEquals(devices[i],device)){
            devices.splice(i,1);
            return;
        }
    }
}
function checkEquals(a,b) {
    if (a.id==b.id
    && a.name==b.name
    && a.address==b.address
    && a.macAddress==b.macAddress
    && a.status==b.status
    && a.type==b.type
    && a.version==b.version)
        return true;
    else
        return false;
}
function myReload() {
    location.reload();
}






