
var authen= btoa("admin:admin");
var app = angular.module('myApp', ["ngRoute"])
    .config(function($httpProvider) {
        $httpProvider.defaults.headers.common['Authorization'] = 'Basic ' + authen;
    })

var id="";
var check=false;
var listDevice= new Array();

app.config(function($routeProvider) {
    $routeProvider
        .when("/", {
            templateUrl : "page/home.html"
        })
        .when("/create", {
            templateUrl : "page/create.html"
        })
        .when("/edit", {
            templateUrl : "page/edit.html"
        });
});
app.controller('myCtrl', function($scope, $http) {
    $scope.getDevices = function () {
        $http.get("http://127.0.0.1:8090/DeviceManagement/api/devices").then(
            function (response) {
                $scope.records = response.data;
                console.log(response.data);
            });
    };
    $scope.getDevices();
    $scope.SendData = function () {

            var data ={
                "name":$scope.device.name,
                "address":$scope.device.address,
                "macAddress":$scope.device.macAddress,
                "type":$scope.device.type,
                "version":$scope.device.version
            }
        console.log("{"+data.name+", "+ data.address+ ", "+data.macAddress+", " + data.type + ", " + data.version + "}");
        if (checkSendData(data)==true){

            var config = {
                headers : {
                    "Content-Type": "application/json;charset=utf-8;"
                }
            }
            var checkCreate= confirm("You want create a device");
            if (checkCreate){
                console.log("You pressed OK");
                $http.post('http://127.0.0.1:8090/DeviceManagement/api/devices', data, config)
                    .then(function(response){
                        $scope.device={};
                        if (response.data!=""){
                            $scope.successCreate="Successful create a device"
                            $scope.errorCreate=""
                            console.log("created ")
                        }
                        else{
                            $scope.errorCreate="Error create a device !"
                            $scope.successCreate=""
                            console.log("error create!")
                        }
                    })
            }else{
                $scope.errorCreate=""
                $scope.successCreate=""
                console.log("You pressed CANCEL")
            }
        }else{
            confirm("You must enter value of device!!");
        }
    };
    $scope.checkDevice = function(device) {
        console.log("device: ["+device.id+","+ device.name+","+device.address+","+device.macAddress+","+device.status+","+device.type+","+device.version+"]");
        check=device.selected;

        if (check==true){
            listDevice.push(device);
        }else{
            removeIndexArray(listDevice,device);
        }
        console.log(listDevice);
        id=device.id;
        $scope.nameEdit= device.name;
        $scope.addressEdit= device.address;
        $scope.typeEdit= device.type;
        $scope.versionEdit= device.version;
        console.log(device);
    };
    $scope.DeleteDevice= function () {
        if (listDevice.length>0){
            var listId=[];
            for(var i=0;i<listDevice.length;i++){
                listId.push(listDevice[i].id);
            }
            var checkConfirm= confirm("You want delete a device?");
            if (checkConfirm==true){
                console.log("You pressed OK");
                $http.delete("http://127.0.0.1:8090/DeviceManagement/api/devices/multiDevice/"+listId).then(
                    function () {
                        $scope.getDevices();
                    });
            }else{
                console.log("You pressed Cancel");
                myReload();
            }
        }else{
            confirm("you must select a device");
        }


    }
    $scope.EditDevice= function () {
        var data={
            "name":$scope.nameEdit,
            "address": $scope.addressEdit,
            "type": $scope.typeEdit,
            "version": $scope.versionEdit
        }
        var config = {
            headers : {
                "Content-Type": "application/json;charset=utf-8;"
            }
        }
        console.log(data)
        var checkEditDevice=confirm("You want edit device?");
        if (checkEditDevice==true){
            console.log("You pressed OK");
            $http.put('http://127.0.0.1:8090/DeviceManagement/api/devices/'+id, data, config)
                .then(function(response){
                    if (response.data!=""){
                        $scope.successUpdate="Successful update a device"
                        $scope.errorUpdate=""
                        console.log("updated ")
                    }
                    else{
                        $scope.errorUpdate="Error update a device !"
                        $scope.successUpdate=""
                        console.log("error update!")
                    }
                })
        }else{

            console.log("You pressed CANCEL");
            window.location = "index.html";
        }


    }
});

function checkSendData(device) {
    if (device.name=="" || device.address=="" || device.macAddress=="" || device.status=="" || device.type=="" || device.version=="")
        return false;
    else
        return true;
}
function removeIndexArray(devices, device) {
    for (var i=0;i<devices.length;i++){
        if (checkIndex(devices[i],device)){
            devices.splice(i,1);
            return;
        }
    }
}
function checkIndex(a,b) {
    if (a.id==b.id
    && a.name==b.name
    && a.address==b.address
    && a.macAddress==b.macAddress
    && a.status==b.status
    && a.type==b.type
    && a.version==b.version)
        return true;
    else
        return false;
}
function myReload() {
    location.reload();
}





